<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-13 13:38:21 --> 404 Page Not Found: Home/index
